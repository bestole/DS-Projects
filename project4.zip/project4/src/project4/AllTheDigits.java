import java.util.Scanner; 

/**
* The AllTheDigits class is used to represent any number as a single digit.
* This method starts by adding all the digits in the number to come up with an equivalent number.
* If the result has more than one digit, the same procedure is applied again and again 
* until the final representation has only one digit.
*
* @author Walker Tupman
*/
public class AllTheDigits {
	
	/**
	* Takes in a number and returns a representation of that number as a single digit.
	* @param number - a long that will be transformed into one single digit.
	* @return a single digit representation of number as a single digit.
	*/
	private static long bruje(long number)
	{
		//sum of all digits of number
		int sum = 0;
		//base case reached after number/10 below
		if(number == 0)
		{
			return number;
		}
		//add right most digit of number to sum
		sum += number % 10;
		//recursive call to get rid of rightmost digit of number
		sum += bruje(number/10);
		//if sum > 9, it is not a single digit, use recursive call to make it single digit
		if(sum > 9)
		{	
		return bruje(sum);
		}
		return sum;
	}
	
	/**
	* Helper method for bruje recursive method.
	* Takes in a number stored in a string variable and returns that number as a single digit. 
	* @param N - a string representation of a number that will be split into parts to be fed into bruje method.
	* @return a representation of N as a single digit.
	*/
	private static long allTheDigits(String N)
	{
		//check if N is a negative number
		boolean negative = false;
		//remove negative sign if it is so bruje method works correctly
		if(N.charAt(0) == '-')
		{
			N = N.substring(1);
			negative = true;
		}
		
		//create variable to hold single digit representation of String N 
		long split = 0;
		//use while loop split N apart into a length that can be converted into a long variable using recursive bruje method
		while(N.length() > 16)
		{
			//add result of 16 length number to split 
			split += bruje(Long.parseLong(N.substring(0, 16)));
			//gets rid of 16 length part of String N that was alrady added to split 
			N = N.substring(16);
		}
		//else just call bruje on string N
		split += bruje(Long.parseLong(N));
		//case where split > 9 to turn it into a single digit
		if(split > 9)
		{
			split = bruje(split);
		}
		//add negative sign back if negative is true
		if(negative)
		{
			return split - (split*2);
		}
		return split;
	}
	
	//takes input and outputs a representation of a number using a single digit
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		String n = input.next();
		System.out.println(allTheDigits(n));
	}
}

