import java.util.Scanner;

/**
* The FibNumbers class is used output the Nth Fibonacci number given the number N.
* Fibonacci numbers are the the sequence of numbers such that each value is the sum of the two
* preceding values starting with the first two values (in this case 1 and 1).
* The first and only line of input contains the number N (1 <= N <= 40).
* Contains one instance variable - check, used to hold all sequences up to the N'th fibonacci number.
* The output contains the value of the N’th Fibonacci number followed by a newline character.
*
* @author Walker Tupman
*/
public class FibNumbers {
	//array to hold calculated fibonacci numbers
	private static int[] check;
	
	/**
	* Takes in a number N and returns the N'th fibonacci number.
	* This object is not modified by call to multiplyByDigit.
	* @param N - a number N (1 <= N <= 40) used to denote what fibonacci number to calculate.
	* @return an int that represents the N'th fibonacci number.
	*/
	public static int fib(int N) 
	{
		//base case, return 1 (start of fibonacci sequence) 
		if(N <= 1)
		{
			return 1;
		}
		
		//check if the Nth fib number is in the array and return it if it is
		if(check[N] != 0)
		{
			return check[N];
		}
		//else calculate the fib number and save it in check
		else
		{
			check[N] = fib(N-2) + fib(N-1);
		}
		//recursive case
		return fib(N-2) + fib(N-1);
	}
	/**
	* Helper method for fib method to instantiate the array check.
	* @param N - a number N (1 <= N <= 40) used to denote what fibonacci number to calculate. 
	* @return calls fib(N-1) in order to return the Nth fibonacci number.
	*/
	public static long fibNumbers(int N)
	{
		//instantiate check array
		check = new int[N];
		return fib(N-1);
	}
	
	//used to get input
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		System.out.println(fibNumbers(n));
	}
}
