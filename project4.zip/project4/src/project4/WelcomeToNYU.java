import java.util.Arrays;
import java.util.Scanner;

/**
* The WelcomeToNYU class is to select exactly two numbers from the given pool whose sum is equal to the target value.
* The first line is a count of numbers in the pool, 0 <= N <= 10, 000
* The second line contains white space separated pool of N number (they may not be unique), each value is a
* positive number less than or equal to 1, 000, 000.
* The third line contains the target value.
* If there are more than one pair that adds up to the target value then pair which is the smallest
* r - p (r and p being a pair of numbers) should be printed.
*
* @author Walker Tupman
*/
public class WelcomeToNYU {
	private static long[] numList;
	/**
	* Calculates the smallest (in terms of absolute value) pair of numbers that add up to target.
	* @param target - a long representing the target number for the pairs to add up to
	* @return a String representation of the pair that add up to target separated by a space 
	* that has the smallest difference (in terms of absolute value).
	*/
	public static String welcomeToNyu(long target)
	{
		//instantiate placeholder pair of numbers
		//negative because this method only takes positive longs
		long one = -1;
		long two = -1;
		//iterate through numList (sorted array) which contains the pool of numbers which could add up to target
		for(int i = 0; i < numList.length; i++)
		{
			//if i > target it can't add up to target, 
			//so stop searching through numList
			if(numList[i] >= target)
			{
				break;
			}
			//iterate through to find pairs of numbers that add up to target
			for(int j = i + 1; j < numList.length; j++)
			{
				//if a pair is greater than target stop searching because the array is sorted
				if(numList[i] + numList[j] > target)
				{
					break;
				}
				//found pair that adds up to target
				if(numList[i] + numList[j] == target)
				{
					//check placeholder to see if you need to compare with past pair
					if(one != - 1)
					{
						//use smaller method to compare the two pairs of numbers 
						if(smaller(one, two, numList[i], numList[i+1]))
						{
							one = numList[i];
							two = numList[j];
						}
					}
					//if there's not a past pair of numbers, save to variables one and two
					else
					{
						one = numList[i];
						two = numList[j];
					}
				}
			}
		}
		return one + " " + two;
	}
	/**
	* Takes in two pairs of numbers and returns true if the second pair is "smaller".
	* Pair one is (long one, long two). Pair two is (long other, long otherTwo).
	* A pair is smaller if their difference in absolute value is smaller than the other pairs difference in absolute value.
	* @param one - a long, paired with param two, that adds up to a number
	* @param two - a long, paired with param one, that adds up to a number
	* @param other - a long, paired with param otherTwo, that adds up to a number
	* @param otherTwo - a long, paired with param other, that adds up to a number
	* @return the pair that has the smaller difference (in absolute value) between them.
	*/
	private static boolean smaller(long one, long two, long other, long otherTwo)
	{
		return Math.abs(other - otherTwo) < Math.abs(one - two);
	}
	
	//takes input of length of a pool of numbers, the pool of numbers, and target
	//prints out pair of smallest (in absolute value) pair of numbers that add up to target
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		numList = new long[input.nextInt()];
		input.nextLine();
		//add pool of numbers to an array and sort it 
		for(int i = 0; i < numList.length; i++)
		{
			numList[i] = input.nextLong();
		}
		Arrays.sort(numList);
		
		input.nextLine();
		long target = input.nextLong();
		System.out.println(welcomeToNyu(target));
	}
}
