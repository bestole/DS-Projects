import java.util.Scanner;

/**
* The DecipherTheMessage class is used to decrypt a message given a key R or D.
* The input to the program contains a key and a message.
* If the key is a D first letter of the message gets dropped.
* If the key is an R, the entire message is reversed.
*
* @author Walker Tupman
*/
public class DecipherTheMessage {
	
	/**
	* Takes a key and encrypted message as input and returns a deciphered message.
	* @param key - a String representing a key that is (1 <= length(key) <= 105) consisting of characters D and R.
	* @param message - a String representing a message that may contain spaces, punctuation marks, other symbols, digits and letters.
	* @return One line containing either the decrypted message or “error”. 
	* In case the resulting message is blank, the program should print a blank line.
	*/
	public static String decipher(String key, String message)
	{
		//StringBuilder object to make reversing and dropping chars more efficient
		StringBuilder converted = new StringBuilder(message);
		//iterate through key and apply changes to message
		for(int i = 0; i < key.length(); i++)
		{
			if(key.charAt(i) == 'R')
			{
				//if there is another R after this one don't reverse and skip over that R
				if(i < key.length() - 1 && key.charAt(i+1) == 'R')
				{
					i++;
				}
				else
				{
					converted.reverse();
				}
			}
			else if(key.charAt(i) == 'D')
			{
				//if key says to drop a character and converted is empty return "error"
				if(converted.length() == 0)
				{
					return "error";
				}
				converted.deleteCharAt(0);
			}
		}
		return converted.toString();
	}
	//takes input of key and message and prints output of deciphered message.
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		String key = input.nextLine();
		String message = input.nextLine();
		System.out.println(decipher(key, message));
	}
}
