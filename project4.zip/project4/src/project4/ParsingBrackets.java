import java.util.Scanner;
import java.util.Stack;

/**
* The ParsingBrackets class is used to parse and validate the use of brackets --> ([{ in code programs.
* A valid sequence of brackets has them correctly nested and sequenced.
* Any sequence of characters that does not include any brackets is a valid program.
* If the key is an R, the entire message is reversed.
* Prints YES if the program is valid or NO followed by the character position (1-based)
* at which the first problem was detected if the program is not valid.
* @author Walker Tupman
*/
public class ParsingBrackets {
	//stack used to push opening of brackets onto ([{ for validation later. 
	//brackets with be popped off top stack if they have a matching closing bracket in the correct order }])
	private static Stack<Character> brackets = new Stack<Character>();
	/**
	* Takes a string and validates the use of brackets.
	* @param line - a String to validated by this method for correct use of brackets.
	* @return YES if the program is valid or NO followed by the character position (1-based)
	* at which the first problem was detected if the program is not valid.
	*/
	public static String parseBracket(String line)
	{
		//iterate through line looking at each character
		for(int i = 0; i < line.length(); i++)
		{
			char brac = line.charAt(i);
			//if character is an opening bracket find out which type of bracket it is
			//then push onto Stack of characters called brackets
			if(brac == '(' || brac == '[' || brac == '{')
			{
				if(brac == '(')
				{
					brackets.push(brac);
				}
				else if(brac == '[')
				{
					brackets.push(brac);
				}
				else
				{
					brackets.push(brac);
				}
			}
			//if character is closing bracket
			else if(brac == ')' || brac == ']' || brac == '}')
			{
				//if brackets is empty, then there is an uneven amount of closing and opening brackets, so return "NO"
				if(brackets.isEmpty())
				{
					return "NO " + (i + 1);
				}
				//save top of stack to variable top
				char top = brackets.peek();
				//check top with it's closing counterpart to validate or not validate
				if(top == '(')
				{
					if(brac != ')')
					{
						//it not valid return "NO" and the place where the error occurred
						return "NO " + (i + 1);
					}
					else
					{
						//if valid pop from stack
						brackets.pop();
					}
				}
				else if(top == '[')
				{
					if(brac != ']')
					{
						return "NO " + (i + 1);
					}
					else
					{
						brackets.pop();
					}
				}
				else
				{
					if(brac != '}')
					{
						return "NO " + (i + 1);
					}
					else
					{
						brackets.pop();
					}
				}
				
			}
		}
		//return "YES" if brackets is empty because all matching pairs have been popped off stack
		if(brackets.isEmpty())
		{
			return "YES";
		}
		return "NO " + (line.length()+1);
	}
	
	
	
	//takes input of line prints output of whether line of code has valid brackets or not.
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		String line = input.nextLine();
		System.out.println(parseBracket(line));
	}
}
