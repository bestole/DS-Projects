import java.util.Scanner;

/**
* The AllPermutations class is used to generate all binary sequences with lengths up to n.
* The input to the program is a non-negative integer indicating the length of the sequence, 0 <= n < 30.
* The output of the program should be a single line containing space separated sequences in alphanumeric order. (See
* the examples below.)
*
* @author Walker Tupman
*/
public class AllPermutations {
	/**
	* Helper method for other allPermutations method so that user doesn't have to provide seq.
	* @param length - length of sequence, 0 <= n < 30 indicating length of binary sequence.
	* @return a formatted String that has all binary sequences with lengths up to n separated by spaces.
	*/
	public static String allPermutations(int length)
	{
		//call recursive allPermutations method
		String done = allPermutations(length, "");
		//if returns an empty string return it
		if(done == "")
		{
			return done;
		}
		//format the output so autograder accepts it
		return " " + done.substring(0, done.length()-1);
	}
	/**
	* Takes in a length and returns all binary sequences with lengths up to n.
	* @param length - length of sequence, 0 <= n < 30 indicating length of binary sequence.
	* @param seq - the sequence to be added onto in the recursive method.
	* @return - a String that has all binary sequences with lengths up to n separated by spaces.
	*/
	public static String allPermutations(int length, String seq)
	{
		//base case to check if seq has reached the max length
		if(seq.length() == length)
		{
			return "";
		}
		//adds 0 to seq 
		String seqZero = seq + "0";
		//adds 1 to seq
		String seqOne = seq + "1";
		//recursive call with seqZero and then recursive call with SeqOne
		String done = seqZero + " " + allPermutations(length, seqZero) + seqOne + " " + allPermutations(length, seqOne);
		return done;
		
		
		
	}
	//takes input and prints output
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int length = input.nextInt();
		System.out.println(allPermutations(length));
	}
}
