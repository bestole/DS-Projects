package project4;

import java.util.Scanner;
import java.util.LinkedList;
import java.util.Queue;

/**
* The CIMSPrinter class is used emulate a printer at Courant Institute of Mathematical Sciences and prints how long a printing job will take in minutes.
* Printing jobs are assigned a priority between 1 and 9 (inclusive) where 9 is highest priority and 1 is the lowest.
* The printing system manages the jobs as follows.
* Select the first job from the queue.
* If there is some job in the queue with higher priority than the selected job then move the selected job to the
* end of the queue without printing it. Otherwise, print that job.
* Assume that there are no additional print jobs added to the queue, printing a single job takes exactly one minute (regardless of its size), and
* the queue operations happen instantly (i.e., there is no additional time spent to manage the queue).
* @author Walker Tupman
*/
public class CIMSPrinter {
	//declare Queue print and instantiate as a linked list to hold all printing jobs.
	private static Queue<Integer> print = new LinkedList<>();
	/**
	* Calculates the amount of time in minutes the target print job will take given a Queue of print jobs.
	* @param pos - an int representing position (starting at 0) of the target print job
	* @param tarPri - an int representing the priority 1 - 9 of the target print job
	* @return a single digit int that represents the amount of minutes it took to print the target print job.
	*/
	public static int printMins(int pos, int tarPri)
	{
		//variable to keep track of how long print job is taking
		int mins = 0;
		//for loop that starts at highest priority and checks that priority is > 0 (because priority is 1 --> 9)
		//also checks to make sure the Queue print is not empty
		for(int i = 9; i > 0 && print.peek() != null;)
		{
			//checks if the Queue contains a print job of priority i in it.
			if(!(print.contains(i)))
			{
				i--;
				continue;
			}
			//if it does have print job of priority i
			else
			{
				//if element at top of queue is i (meaning highest priority in Queue) then add 1 to mins and remove it from print.
				if(print.element() == i)
				{
					mins++;
					print.remove();
					//if the target print job is at pos 0 and it is the highest priority job in the queue returns mins
					if(pos == 0 && i == tarPri)
					{
						return mins;
					}
					//print removed first print job in queue so target print job moves one position closer
					pos--;
				}
				else
				{
					//move print job to back of queue because it is not the highest priority job
					print.add(print.remove());
					//update position of target job if it is at front of queue because it gets moved to back
					if(pos == 0)
					{
						pos = print.size() - 1;
					}
					//update position of target job by moving it one forward
					else
					{
						pos--;
					}
				}
			}
		}
		return mins;
	}
	
	//takes input and returns output which represents how long the print job will take in minutes
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		int length = input.nextInt();
		int position = input.nextInt();
		int targetPriority = 0;
		input.nextLine();
		for(int i = 0; i < length; i++)
		{
			int current = input.nextInt();
			print.add(current);
			if(i == position)
			{
				targetPriority = current;
			}
		}
		System.out.println(printMins(position, targetPriority));
	}
}
