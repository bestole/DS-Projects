package project2;
import java.util.*;

/**
* The Number class is used to represent positive integers. 
* It provides several operations to support number manipulation: addition, multiplication and comparisons.
* There is no limit to the number of digits in a Number object.
* The numbers are represented in the form of a linked list. Each node in the list contains a single digit.
*
* @author Walker Tupman
*/
public class Number extends Object implements Comparable<Number> {
	
	private Node head;
	private Node tail;
	private int length;
	
	/**
	* The Node class is used to represent a node of the Number object.
	* Each node has a reference to the next node in the list 
	* It also has a reference to the previous node in the list.
	* Each node represents a single positive digit.
	* @author Walker Tupman
	*/
	private class Node{
		
		public int digit;
		public Node next;
		public Node back;
		
		/**
		* Creates a Node object with value represented by the integer argument digit. 
		* The number should consist of positive decimal digits only.
		* @param digit - an integer representation of the data that the node is holding.
		*/
		public Node(int digit) {
			
			this.digit = digit;
			this.next = null;
			this.back = null;
			
		}
	}
	
	/**
	* Creates a Number object with value represented by the string argument number. 
	* The number should consist of decimal digits only.
	* @param number - a string representation of the number
	* @throws NullPointerException - if number is null
	* @throws IllegalArgumentException - if number contains any illegal characters
	*/
	public Number(String number) throws IllegalArgumentException, NullPointerException
	{
		//check if number is null and empty and throw exception if it is
		if(number == null || number.length() == 0)
		{
			throw new NullPointerException("Do not pass in null or an empty string.");
		}
		
		//get rid of leading zeroes for input
		for(int i  = 0; i < number.length()-1; i++)
		{
			if(number.charAt(0) == '0')
			{
				if(number.charAt(i) == '0' && number.charAt(i+1) != '0')
				{
					number = number.substring(i + 1);
				}
			}
		}
		//declare variables for later
		length = number.length();
		Node current;
		char digit;
		Node temp;
		Node previous;
		//try catch block to catch the potential errors that parseInt might create
		try {
			//creates first node of list using create method and instantiates head/tail
			current = create(number.charAt(number.length()-1));
			head = current;
			tail = head;
		//creates rest of linked list and attach it to first node
		//also sets back and next values for each Node in list where applicable
			for(int i = number.length()-2 ; i > -1; i--)
			{
				digit = number.charAt(i);
				temp = create(digit);
				previous = current;
				current.next = temp;
				current = temp;
				current.back = previous;
				if(i == 0)
				{
					tail = current;
				}
			}
		}
		//catch negative signs and illegal characters
		catch(NumberFormatException e)
		{
			throw new IllegalArgumentException("Please only use positive integers as input.");
		}
		
	}
	
	/**
	* Takes in a character and returns a Node object with an integer inside.
	* This object is not modified by call to multiplyByDigit.
	* @param num - a single character to be turned into an integer.
	* @return a Node object whose value data is equal to the character that was inputted.
	*/
	private Node create(char num)
	{
		//convert char to int and use that int to create/return Node n
		int number;
		number = Integer.parseInt(String.valueOf(num));
		Node digit = new Node(number);
		
		return digit;
	}
	
	/**
	* Computes the sum of this object with other. Returns the result in a new object. 
	* This object is not modified by call to add.
	* @param other - the value to be added to this object
	* @return a Number object whose value is equal to the sum of this object and other
	* @throws NullPointerException - if other is null
	*/
	public Number add(Number other) throws NullPointerException
	{
		//check for exception
		if(other == null)
		{
			throw new NullPointerException("Do not pass in null.");
		}
		//create place holders for start of list and variables to do the math required in this method 
		Number sum = new Number("0");
		int carry = 0;
		int add;
		//iterators to go through both Number objects
		Node tCurrent = this.head;
		Node oCurrent = other.head;
		//count to keep track of length of number object sum that is returned from this method
		int count = 1;
		//temp node for later
		Node dummy = new Node(0);
		//check for length and use different for loops accordingly 
		if(this.length > other.length)
		{
			//iterate through larger list and add to Number object sum
			for(int i = 0; i < this.length; i++)
			{
				//do math and add result of "add" variable to Node end
				add = tCurrent.digit;
				tCurrent = tCurrent.next;
				if(oCurrent != null)
				{
					add += oCurrent.digit;
					oCurrent = oCurrent.next;
				}
				add += carry;
				carry = add / 10;
				if(i < this.length - 1)
				{	
					add %= 10;
				}
				Node end = new Node(add);
				//re-instantiate start of list to be correct
				if(i == 0)
				{
					sum = new Number("" + add);
				}
				//edge-case where digit has to broken apart
				else if(end.digit > 9)
				{	
					dummy.digit = end.digit % 10;
					sum.tail.next = dummy;
					sum.tail = sum.tail.next;
					count++;
					end.digit /= 10;
					sum.tail.next = end;
					sum.tail = sum.tail.next;
					count++;
				}
				//adds new "sum" to end of sum object and moves tail to new end
				else
				{
					sum.tail.next = end;
					sum.tail = sum.tail.next;
					count++;
				}
			}
		}
		else
		{
			//same as other loop but for cases where other is bigger / the two Numbers are same size
			for(int i = 0; i < other.length; i++)
			{
				add = oCurrent.digit;
				oCurrent = oCurrent.next;
				if(tCurrent != null || this.length == other.length)
				{
					add += tCurrent.digit;
					tCurrent = tCurrent.next;
				}
				add += carry;
				carry = add / 10;
				if(i < other.length - 1)
				{
					add %= 10;
				}
				Node end = new Node(add);
				if(i == 0)
				{
					sum = new Number("" + add);
				}
				else if(end.digit > 9)
				{	
					dummy.digit = end.digit % 10;
					sum.tail.next = dummy;
					sum.tail = sum.tail.next;
					count++;
					end.digit /= 10;
					sum.tail.next = end;
					sum.tail = sum.tail.next;
					count++;
				}
				else
				{
					sum.tail.next = end;
					sum.tail = sum.tail.next;
					count++;
				}
			}
		}
		//reset length for sum
		sum.length = count;
		
		return sum;
	}
	
	/**
	* Compares this object with other for order. 
	* Returns a negative integer if this object's value is strictly smaller than the value of other. 
	* Returns a positive integer if this object's value is strictly greater than the value of other. 
	* Returns zero if two values are the same.
	* @param other - the object to be compared with this object
	* @return a negative integer, zero, or a positive integer as this object is less than, equal to, or greater than other
	* @throws NullPointerException - if other is null
	*/
	public int compareTo(Number other) throws NullPointerException
	{
		//check for exceptions / constant time cases
		if(other == null)
		{
			throw new NullPointerException("Do not pass in null as an argument.");
		}
		
		if(this == other)
		{
			return 0;
		}
		if(this.length < other.length)
		{
			return -1;
		}
		else if(this.length > other.length)
		{
			return 1;
		}
		
		//create iterators
		Node tCurrent = this.tail;
		Node oCurrent = other.tail;
		//iterate through list backwards and check for comparisons
		for(int i = 0; i < other.length; i++)
		{
			if(tCurrent.digit > oCurrent.digit)
			{
				return 1;
			}
			else if(tCurrent.digit < oCurrent.digit)
			{
				return -1;
			}
			tCurrent = tCurrent.back;
			oCurrent = oCurrent.back;
		}
		
		return 0;
	}
	
	/**
	* Determines if this object is equal to obj. 
	* Two Number objects are equal if all of their digits are the same and in the same order,
	* and if they have the same number of digits. 
	* In other words, if the values represented by the two objects are the same.
	* @param obj - the object to be compared to this object
	* @return true if two objects are equal, false otherwise
	*/
	@Override
	public boolean equals(Object obj)
	{
		//check for constant cases
		if(this == obj)
		{
			return true;
		}
		if(!(Number.class.isInstance(obj)))
		{
			return false;
		}
		
		//cast obj to Number class
		Number o = (Number)obj;
		
		if(this.length != o.length)
		{
			return false;
		}
		
		//create iterators
		Node tCurrent = this.head;
		Node oCurrent = o.head;
		//iterate through and check every value in both Numbers for equality
		for(int i = 0; i < o.length; i++)
		{
			if(tCurrent.digit != oCurrent.digit)
			{
				return false;
			}
			tCurrent = tCurrent.next;
			oCurrent = oCurrent.next;
		}
		return true;
	}
	
	/**
	* Returns the number of digits in this object.
	* @return the number of digits in this object
	*/
	public int length()
	{
		return this.length;
	}
	
	/**
	* Adds zeros to the end of a Number object and returns that object.
	* @param other - a Number object which zeroes will be added onto the end of.
	* @param iteration - an integer that dictates the amount of zeroes which will be added ot the end.
	* @return a Number object that has (iteration) amount of zeroes added to the end of it.
	*/
	private Number repeatZero(Number other, int iteration)
	{
		Number zero = other;
		Node end;
		//iterates through (iteration) times and adds that many zeroes to end of Number object zero
		for(int i = 0; i < iteration; i++)
		{
			zero.length++;
			end = new Node(0);
			end.next = zero.head;
			zero.head = end;
		}
		
		return zero;
	}
	
	/**
	* Computes the product of this object and other. Returns the result in a new object. 
	* This object is not modified by call to multiply.
	* @param other - the value to be multiplied by this object
	* @return a Number object whose value is equal to the product of this object and other object
	* @throws NullPointerException - if other is null
	*/
	public Number multiply(Number other) throws NullPointerException
	{
		//error check 
		if(other == null)
		{
			throw new NullPointerException("Do not pass in null as an argument.");
		}
		
		//test for 0 case
		Number product;
		
		if(other.tail.digit == 0 || this.tail.digit == 0)
		{
			return product = new Number("0");
		}
		
		Number temp;
		Node current;
		//if else based on length
		if(this.length > other.length)
		{
			//create iterator 
			current = other.head;
			//set product equal to first instance of multiplyByDigit 
			product = this.multiplyByDigit(current.digit);
			for(int i = 1; i < other.length; i++)
			{
				current = current.next;
				//temp Number object to hold another instance of multiplyByDigit
				temp = this.multiplyByDigit(current.digit);
				//add zeroes to end of temp
				temp = repeatZero(temp, i);
				//add product to previous product 
				product = product.add(temp);
			}
		}
		//same as block above
		else
		{
			current = this.head;
			product = other.multiplyByDigit(current.digit);
			for(int i = 1; i < this.length; i++)
			{
				current = current.next;
				temp = other.multiplyByDigit(current.digit);
				temp = repeatZero(temp, i);
				product = product.add(temp);
			}
		}
		
		return product;
	}
	
	/**
	* Computes the product of this object and a single digit digit. Returns the result in a new object.
	* This object is not modified by call to multiplyByDigit.
	* @param digit - a single positive digit to be used for multiplication
	* @return a Number object whose value is equal to the product of this object and digit
	* @throws IllegalArgumentException - when digit is invalid (i.e., not a single digit or negative)
	*/
	public Number multiplyByDigit(int digit) throws IllegalArgumentException
	{
		//error check
		if(digit < 0 || digit > 9)
		{
			throw new IllegalArgumentException("Number inputted is negative or more than one digit");
		}
		
		//create place holders for start of list and variables to do the math required in this method 
		Node current = head;
		int carry = 0;
		int mult;
		//start of Number
		Number multDigit = new Number("0");
		Node dummy = new Node(0);
		//count to keep track of multDigit length
		int count = 1;
		
		for(int i = 0; i < this.length; i++)
		{
			//store carry for next iteration in carry and leftover digit in mult
			mult = current.digit * digit;
			mult += carry;
			current = current.next;
			carry = mult / 10;
			if(i != this.length - 1)
			{
				mult %= 10;
			}
			//create node to hold mult and link to multDigit later
			Node end = new Node(mult);
			//re-instantiate multDigit to be correct for first digit
			if(i == 0)
			{
				multDigit = new Number(""+mult);
			}
			//edge case where end.digit > 9, occurring in last iteration 
			//because of if statement on line 436
			else if(end.digit > 9)
			{	
				dummy.digit = end.digit % 10;
				multDigit.tail.next = dummy;
				multDigit.tail = multDigit.tail.next;
				count++;
				end.digit /= 10;
				multDigit.tail.next = end;
				multDigit.tail = multDigit.tail.next;
				count++;
			}
			//adds new product to end of MultDigit and moves tail to new end of MultDigit
			else
			{
				multDigit.tail.next = end;
				multDigit.tail = multDigit.tail.next;
				count++;
			}
		
		}
		//reset multDigit to correct length
		multDigit.length = count;

		return multDigit;
	}
	
	/**
	* Returns the string representation of this object.
	* @return string representation of this object
	*/
	@Override
	public String toString()
	{
		//iterate through Number object and add each node.digit backwards to String "rep"
		Node current = this.head;
		String rep = "";
		
		for(int i = 0; i < length; i++)
		{
			rep = current.digit + rep;
			current = current.next;
		}
		
		return rep;
	}
}
