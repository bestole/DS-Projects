package project5;
import java.util.*;

/**
* The BST class is a generic implementation of a binary search tree. 
* The elements are ordered using their natural ordering.
* This implementation provides guaranteed O(H) 
* (H is the height of this tree which could be as low as logN for balanced trees,
* but could be as large as N for unbalanced trees) time cost for the basic operations (add, remove and contains).
* This class implements many of the methods provided by the Java framework's TreeSet class.
*
* @author Walker Tupman
* @version 05/01/2023
*/
public class BST<E extends Comparable<E>> implements Iterable<E>
{
	//declare instance variables
	private Node root;
	private int size;
	
	/**
	* Constructs a new, empty tree, sorted according to the natural ordering of its elements. 
	* All elements inserted into the tree must implement the Comparable interface.
    * This operation is O(1).
	*/
	public BST()
	{
		//root is null because empty tree
		root = null;
	}
	
	/**
	* Constructs a new tree containing the elements in the specified collection, 
	* sorted according to the natural ordering of its elements. 
	* All elements inserted into the tree must implement the Comparable interface.
    * This operation is O(N logN).
    * @param collection - collection whose elements will comprise the new tree
    * @throws NullPointerException - if the specified collection is null
	*/
	public BST(E[] Collection) throws NullPointerException
	{
		//sort Collection so can make balanced tree
		Arrays.sort(Collection);
		//recursive method to add elements from Collection to make a balanced tree
		addCollection(Collection, 0, Collection.length);
		
	}
	
	/**
	* Recursive helper method for public BST(E[] Collection) constructor.
	* Constructs a new balanced tree based on natural ordering from a collection of elements.
	* Midpoint of E[] Collection is the root of the tree.
	* @param Collection - a collection of generic E elements to be made into a balanced tree.
	* @param start - an integer that represents the starting index of the Collection array.
	* @param end - an integer that represents the ending index of the Collection array.
	*/
	public void addCollection(E[] Collection, int start, int end)
	{
		//mid point of this iteration of recursive method
        int mid = (start+end)/2;
        //base case
        if(start >= end)
        {
        	//add to tree
            this.add(Collection[0]);
            return;
        }
        //adds midPoint
        this.add(Collection[mid]);
        //create left sub tree
        addCollection(Collection, 0, mid);
        //create right sub tree
        addCollection(Collection, mid+1, end);
	}
	
	/**
	* Adds the specified element to this set if it is not already present. 
	* More formally, adds the specified element e to this tree if the set contains no element e2 such that Objects.equals(e, e2). 
	* If this set already contains the element, the call leaves the set unchanged and returns false.
    * This operation should be O(H).
    * Inspired from BST class implementation we did in lecture on Ed.
	* @param e - element to be added to this set
	* @return true if this set did not already contain the specified element
	* @throws NullPointerException - if the specified element is null and this set uses natural ordering, 
	* or its comparator does not permit null elements
	*/
	 public boolean add (E e) throws NullPointerException
	 { 
		 //create first node in tree
		 if (root == null ) 
		 {
			root = new Node(e); 
	        size++;
	        return true;
	     }
		 
	     //reference to root to iterate through this BST
	     Node current = root;
	     
	     //iterate through tree to find where to add element e
	     while (current != null ) 
	     {
	    	//add element to left side of tree
	        if (e.compareTo(current.data) < 0) 
	        {
	        	if (current.left == null) 
	            {
	                current.left = new Node (e);
	                //iterate size one higher since node is added
	                size++;
	                return true; 
	            }
	            else
	            {
	                current = current.left; 
	            }
	        }
	        //add element to right side of tree
	        else if (e.compareTo(current.data) > 0 ) 
	        {
	        	if (current.right == null) 
	            {
	                current.right = new Node (e);
	                size++;
	                return true; 
	            }
	            else 
	            {
	                current = current.right; 
	            }
	        }
	        else 
	        {
	        	//element is a duplicate 
	        	return false; 
	        }
	     }
	     //shoudn't reach this 
	     return false; 
	 }
	
	/**
	* Removes the specified element from this tree if it is present. 
	* More formally, removes an element e such that Objects.equals(o, e), if this tree contains such an element. 
	* Returns true if this tree contained the element (or equivalently, if this tree changed as a result of the call). 
	* (This tree will not contain the element once the call returns.)
    * This operation should be O(H).
    * Inspired from BST class implementation we did in lecture on Ed.
	* @param o - object to be removed from this set, if present
	* @return true if this set contained the specified element
	* @throws ClassCastException - if the specified object cannot be compared with the elements currently in this tree
	* @throws NullPointerException - if the specified element is null
	*/
	public boolean remove(Object o) throws NullPointerException, ClassCastException
	{
		//nothing to remove if tree is null
		if(root == null)
		{
			return false;
		}
		
		//variable to hold node to remove 
		Node remove = null;
		//reference of root to iterate through tree
		Node current = root;
		//suppress warning because this cast is fine
		//cast Object to generic E
		@SuppressWarnings("unchecked")
		E other = (E)o;
		//boolean to check whether to remove left or right node
		boolean left = false;
		boolean right = false;
		//if o is equal to root, and root has two children, remove root and return true
		//had to hard code this because weird edge case 
		if(Objects.equals(o, root.data) && (root.left != null) && (root.right != null))
		{
			//root is object to be removed
			remove = root;
			//get successor
			Node successor = new Node(successor(remove));
			//fix successor left and right references to be correct for tree
			successor.left = remove.left;
			successor.right = remove.right;
			//reset root for successor
			root = successor;
			return true;
		}
		//condition in case root doesn't have children but is object to be removed
		else if(!(Objects.equals(o, root.data)))
		{
			//iterate through list to find Object o to remove
			while(current != null)
			{
				//check left to see if it's the element to be removed
				if(current.left != null && Objects.equals(o, current.left.data))
				{
					//set remove to current.left
					remove = current.left;
					//set boolean value
					left = true;
					//exit loop
					break;
				}
				//check right to see if it's the element to be removed
				else if(current.right != null && Objects.equals(o, current.right.data))
				{
					//do same as for left side above
					remove = current.right;
					right = true;
					break;
				}
				//comparison in order to find where to iterate to in this BST
				int compare = current.data.compareTo(other);
				if(compare < 0)
				{
						current = current.right;
				}
				else if(compare > 0) 
				{
					current = current.left;
				}
			}
	
		//if left and right are false then element is not in this tree
		if(!(left || right))
		{
			return false;
		}
		//removing leaf node case
		if(remove.right == null && remove.left == null)
		{
			if(left) current.left = null;
			if(right) current.right = null;
		}
		//removing node with one child
		else if(remove.right == null)
		{
			if(left) current.left = remove.left;
			if(right) current.right = remove.left;
		}
		else if(remove.left == null)
		{
			if(left) current.left = remove.right;
			if(right) current.right = remove.right;
		}
		//removing node with two children
		else
		{
			//create successor Node
			Node successor = new Node(successor(remove));
			//reset ./left for successor
			successor.left = remove.left;
			successor.right = remove.right;
			if(left) current.left = successor;
			if(right) current.right = successor;
			
		}
		}
		//fix size
		size--;
		return true;
	}
	
	/**
	* Returns the data from the successor of the node to be removed.
    * The data is generic E.
	* @param node - the node from this BST to be removed.
	* @return data - the data from node's nearest successor
	* @throws NullPointerException - if node is null
	*/
	 private E successor(Node node) throws NullPointerException
	 {
		 //reference of node given to iterate through rest of BST
		 Node current = node;
		 //go right because getting successor
		 current = current.right;
		 //if left is null return 
		 if(current.left == null)
		 {
			 return current.data;
		 }
		 //go far left as possible
		 while(current.left.left != null)
		 {
			 current = current.left;
		 }
		 //get element from current.left
		 E data = current.left.data;
		 
		 //reset pointers for tree to be correct 
		 current.left = current.left.right;
		 
		 return data;
	 }
	 
	/**
	* Removes all of the elements from this set. 
	* The set will be empty after this call returns.
	* This operation should be O(1).
	*/
	public void clear()
	{
		this.size = 0;
		root = null;
	}
	
	/**
    * Returns true if this set contains the specified element. 
    * More formally, returns true if and only if this set contains an element e such that Objects.equals(o, e).
	* This operation should be O(H).
	* @param o - object to be checked for containment in this set
	* @return true if this set contains the specified element
	* @throws ClassCastException - if the specified object cannot be compared with the elements currently in the set
	* @throws NullPointerException - if the specified element is null and this set uses natural ordering, 
	* or its comparator does not permit null elements
	*/
	public boolean contains(Object o) throws ClassCastException, NullPointerException
	{
		//create reference to root to iterate through tree
		Node current = root;
		
		//suppress warnings because wouldn't compile and this seems fine
		@SuppressWarnings("unchecked")
		//case Object o to generic E so that you can use compareTo
		E other = (E)o;
		while(current != null)
		{
			//if equal then this tree contains element 
			if(Objects.equals(o, current.data))
			{
				return true;
			}
			int compare = current.data.compareTo(other);
			if(compare < 0)
			{
					current = current.right;
			}
			else if(compare > 0) 
			{
				current = current.left;
			}
			
		}
		return false;
	}
	
	/**
	* Returns the number of elements in this tree.
	* This operation should be O(1).
	* @returns the number of elements in this tree
	*/	
	public int size()
	{
		return this.size;
	}
	
	/**
	* Returns true if this set contains no elements.
	* This operation should be O(1).
	* @returns true if this set contains no elements
	*/	
	public boolean isEmpty()
	{
		//java garbage collector should delete rest of tree
		return root == null;
	}
	
	/**
	* Returns the height of this tree. The height of a leaf is 1. 
	* The height of the tree is the height of its root node.
	* This operation should be O(1).
	* @return the height of this tree or zero if the tree is empty
	*/	
	public int height()
	{
		//if root is null then height is 0
		//if(root == null) return 0;
		int height = getHeight(root);
		
		return height;
	}
	
	/**
	* Recursive helper method for height()
	* Calculates and returns the height of this BST recursively.
	* The height of the tree is the height of its root node.
	* @param node - the node to calculate the height of
	* @return the height of this tree or zero if the tree is empty
	*/	
	int getHeight(Node node) 
	{
		//base case 
		if (node == null) 
		{
			return 0;
		}
		
		//recursive call to getHeight that explores tree and finds deepest path
		return 1 + Math.max(getHeight(node.left), getHeight(node.right));
	}
	
	/**
	* Returns an iterator over the elements in this tree in ascending order.
	* This operation should be O(N).
	* Specified by: iterator in interface Iterable<E extends Comparable<E>>
	* @return an iterator over the elements in this set in ascending order
	*/	
	public Iterator<E> iterator()
	{
		return new BSTIterator("inorder");
	}
	
	/**
	* Returns an iterator over the elements in this tree in order of the preorder traversal.
	* This operation should be O(N).
	* @return an iterator over the elements in this tree in order of the preorder traversal
	*/	
	public Iterator<E> preorderIterator()
	{
		return new BSTIterator("preorder");
	}
	
	/**
	* Returns an iterator over the elements in this tree in order of the postorder traversal.
	* This operation should be O(N).
	* @return an iterator over the elements in this tree in order of the postorder traversal
	*/	
	public Iterator<E> postorderIterator()
	{
		return new BSTIterator("postorder");
	}
	
	/**
	* Returns the element at the specified position in this tree.
	* The order of the indexed elements is the same as provided by this tree's iterator. 
	* The indexing is zero based (i.e., the smallest element in this tree is at index 0 
	* and the largest one is at index size()-1).
	* This operation should be O(H).
	* @param index - index of the element to return
	* @return the element at the specified position in this tree
	* @throws IndexOutOfBoundsException - if the index is out of range (index < 0 || index >= size())
	*/
	public E get(int index) throws IndexOutOfBoundsException
	{
		//get inorder ArrayList of elements from this tree
		ArrayList<E> tree = this.toArray("inorder");
		return tree.get(index);
	}
	
	/**
	* Returns the least element in this tree greater than or equal to the given element, 
	* or null if there is no such element.
	* This operation should be O(H).
	* @param e - the value to match
	* @return the least element greater than or equal to e, or null if there is no such element
	* @throws ClassCastException - if the specified element cannot be compared with the elements currently in the set
	* @throws NullPointerException - if the specified element is null
	*/
	public E ceiling(E e) throws ClassCastException, NullPointerException
	{
		//create reference of root to iterate through BST
		Node current = root;
		//variable to save least element greater than or equal to e
		E ceiling = null;
		
		//iterate through BST to find least element greater than or equal to e
		while(current != null)
		{
			//if equal return element e 
			if(Objects.equals(current.data, e))
			{
				return e;
			}
			
			int compare = current.data.compareTo(e);
			
			if(compare < 0)
			{	
				current = current.right;
			}
			else if(compare > 0) 
			{
				//first element greater than e saved to ceiling
				if(ceiling == null)
				{
					ceiling = current.data;
				}
				//compare to see if this element is greater than element saved in higher
				//also is less than e
				if(current.data.compareTo(ceiling) < 0)
				{
					ceiling = current.data;
				}
				current = current.left;
			}
		}
		return ceiling;
	}
	
	/**
	* Returns the greatest element in this set less than or equal to the given element, 
	* or null if there is no such element.
	* This operation should be O(H).
	* @param e - the value to match
	* @return the greatest element less than or equal to e, or null if there is no such element
	* @throws ClassCastException - if the specified element cannot be compared with the elements currently in the set
	* @throws NullPointerException - if the specified element is null
	*/
	public E floor(E e) throws ClassCastException, NullPointerException
	{
		//create reference of root to iterate through BST
		Node current = root;
		//variable to save greatest element less than or equal to e
		E floor = null;
		
		//iterate through BST to find greatest element less than or equal to e
		while(current != null)
		{
			//if equal return element e 
			if(Objects.equals(current.data, e))
			{
				return e;
			}
			
			int compare = current.data.compareTo(e);
			
			if(compare < 0)
			{	
				//first element lower than e saved to floor
				if(floor == null)
				{
					floor = current.data;
				}
				//compare to see if this element is greater than element saved in higher
				//also is less than e
				if(current.data.compareTo(floor) > 0)
				{
					floor = current.data;
				}
				current = current.right;
			}
			else if(compare > 0) 
			{
				current = current.left;
			}
		}
		return floor;
	}
	
	/**
	* Returns the first (lowest) element currently in this tree.
	* This operation should be O(H).
	* @return the first (lowest) element currently in this tree
	* @throws NoSuchElementException - if this set is empty
	*/
	public E first() throws NoSuchElementException
	{
		//throw exception for edge case
		if(root == null)
		{
			throw new NoSuchElementException("set is empty");
		}
		
		//reference to root to iterate through BST
		Node current = root;
		
		//go as far right in BST as possible to find biggest element
		while(current.left != null)
		{
			current = current.left;
		}
		 return current.data;
	}
	
	/**
	* Returns the last (highest) element currently in this tree.
	* This operation should be O(H).
	* @return the last (highest) element currently in this tree
	* @throws NoSuchElementException - if this set is empty
	*/
	public E last() throws NoSuchElementException
	{
		//throw exception for edge case
		if(root == null)
		{
			throw new NoSuchElementException("set is empty");
		}
		
		//reference to root to iterate through BST
		Node current = root;
		
		//go as far right in BST as possible to find biggest element
		while(current.right != null)
		{
			current = current.right;
		}
		 return current.data;
	}
	
	/**
	* Returns the greatest element in this set strictly less than the given element, 
	* or null if there is no such element.
	* This operation should be O(H).
	* @param e - the value to match
	* @return the greatest element less than e, or null if there is no such element
	* @throws ClassCastException - if the specified element cannot be compared with the elements currently in the set
	* @throws NullPointerException - if the specified element is null
	*/
	public E lower(E e) throws ClassCastException, NullPointerException
	{
		//create reference of root to iterate through BST
		Node current = root;
		//variable to save greatest element strictly less than e
		E lower = null;
		
		//iterate through BST to find greatest element strictly less than e
		while(current != null)
		{
			int compare = current.data.compareTo(e);
			
			//if equal keep looking
			if(Objects.equals(current.data, e))
			{
				current = current.left;
			}
			else if(compare < 0)
			{	
				//first element lower than e saved to lower
				if(lower == null)
				{
					lower = current.data;
				}
				//compare to see if this element is greater than element saved in higher
				//also is less than e
				if(current.data.compareTo(lower) > 0)
				{
					lower = current.data;
				}
					current = current.right;
			}
			else if(compare > 0) 
			{
				current = current.left;
			}
		}
		return lower;
	}
	
	/**
	* Returns the least element in this tree strictly greater than the given element, 
	* or null if there is no such element.
	* This operation should be O(H).
	* @param e - the value to match
	* @return the least element greater than e, or null if there is no such element
	* @throws ClassCastException - if the specified element cannot be compared with the elements currently in the set
	* @throws NullPointerException - if the specified element is null
	*/
	public E higher(E e) throws ClassCastException, NullPointerException
	{
		//create reference of root to iterate through BST
		Node current = root;
		//variable to save least element strictly greater than e
		E higher = null;
		
		//iterate through BST to find least element strictly greater than e
		while(current != null)
		{
			int compare = current.data.compareTo(e);
			
			//if equal keep looking
			if(Objects.equals(current.data, e))
			{
				current = current.right;
			}
			else if(compare < 0)
			{	
				current = current.right;
			}
			else if(compare > 0) 
			{
				//first element greater than e saved to higher
				if(higher == null)
				{
					higher = current.data;
				}
				//compare to see if this element is less than element saved in higher
				//also is greater than e
				if(current.data.compareTo(higher) < 0)
				{
					higher = current.data;
				}
				current = current.left;
			}
		}
		return higher;
	}
	
	/**
	* Compares the specified object with this tree for equality. 
	* Returns true if the given object is also a tree, the two trees have the same size, 
	* and every member of the given tree is contained in this tree.
	* This operation should be O(N).
	* @param obj - object to be compared for equality with this tree
	* @return true if the specified object is equal to this trees
	*/
	@Override
	public boolean equals(Object obj)
	{
		//check for edge cases
		if(obj == null)
		{
			return false;
		}
		if(obj == this)
		{
			return true;
		}
		if(!(obj instanceof BST))
		{
			return false;
		}
		
		//cast obj to tree 
		BST<?> bst = (BST <?>) obj;
		if(this.size() != bst.size())
		{
			return false;
		}
		
		//make inorder ArrayList of both trees
		ArrayList<E> thisList = this.toArray("inorder");
		ArrayList<?> bstList = bst.toArray("inorder");

		//compare trees
		for(int i = 0; i < thisList.size(); i++)
		{
			if(thisList.get(i) != bstList.get(i))
			{
				return false;
			}
		}
		
		return true;
	}
	
	/**
	* Returns a string representation of this tree. 
	* The string representation consists of a list of the tree's elements in the order they are returned by its iterator 
	* (inorder traversal), enclosed in square brackets ("[]"). 
	* Adjacent elements are separated by the characters ", " (comma and space).
	* This operation should be O(N).
	* @return a string representation of this collection
	*/
	@Override
	public String toString()
	{
		//StringBuilder object to hold string representation of this tree
		StringBuilder toString = new StringBuilder();
		//get inorder ArrayList with this tree's elements 
		ArrayList<E> tree = this.toArray("inorder");
		//iterate through, append to StringBuilder, and format elements
		for(int i = 0; i < tree.size(); i++)
		{
			toString.append("[");
			toString.append(String.valueOf(tree.get(i)));
			toString.append("]");
			if(i != tree.size() - 1)
			{
				toString.append(",");
			}
		}
		return toString.toString();
	}
	
	/**
	* Produces tree like string representation of this tree. 
	* Returns a string representation of this tree in a tree-like format. 
	* The string representation consists of a tree-like representation of this tree. 
	* Each node is shown in its own line with the indentation showing the depth of the node in this tree. 
	* The root is printed on the first line, followed by its left subtree, followed by its right subtree.
	* This operation should be O(N).
	* Inspired from BST class implementation we did in lecture on Ed.
	* @return string containing tree-like representation of this tree.
	*/
	public String toStringTreeFormat()
	{
		//instantiate StringBuffer object to hold BST String representation of tree
		StringBuffer sb = new StringBuffer();
		//call recursive method
        toStringTree(sb, root, 0);
        return sb.toString();
	}
	
	/**
	* Recursive helper method for toStringTreeFormat()
	* Appends each node of a BST onto a StringBuffer object.
	* The string representation consists of a tree-like representation of this tree. 
	* Inspired from BST class implementation we did in lecture on Ed.
	* @param sb - the StringBuffer to be appended onto that will represent this BST
	* @param node - the node that will be added onto the StringBuffer
	* @param level - the level that the parameter node is on.
	* @throws NullPointerException - if node is null
	*/
	private void toStringTree( StringBuffer sb, Node node, int level ) {
		//add indentation per level 
        if (level > 0 ) {
            for (int i = 0; i < level-1; i++) {
                sb.append("   ");
            }
            sb.append("|--");
        }
        //append null if node is null
        if (node == null) {
            sb.append( "null\n"); 
            return;
        }
        else {
        	//append data
            sb.append( node.data + "\n"); 
        }
        
        //display the left subtree 
        toStringTree(sb, node.left, level+1); 
        //display the right subtree 
        toStringTree(sb, node.right, level+1); 
    }
	
	/**
	* The Node class is used to represent a generic node in a Binary Search Tree.
	* Each node has a left and right reference.
	* A left reference should hold a Node that is "less than" the parent node,
	* and the right reference should hold a Node that is "greater than" the parent node.
	* It also has a reference to the previous node in the list.
	* Each node holds a generic E data.
	* Each node also has an integer height to keep track of its height in the BST.
	* 
	* @author Walker Tupman
	* @version 05/01/2023
	*/
	protected class Node
	{
		//declare instance variables
		protected E data;
		protected Node left;
		protected Node right;
		
		/**
		* Creates a generic Node object that holds data
		* It holds the generic E data.
		* @param data - a generic representation of the data that the node is holding.
		*/
		public Node(E data)
		{
			//instantiate data
			this.data = data;
		}
	}
	
	/**
	* Returns the data inside of a node.
	* It holds the generic E data.
	* @param node - a generic node from this BST
	* @return data - the generic E data inside of a node.
	* @throws NullPointerException - if node is null.
	*/
	protected E getData(Node node) throws NullPointerException
	{
		return node.data;
	}
	
	/**
	* The BSTIterator class is a generic iterator for this Binary Search Tree implementation.
	* A BSTIterator object can provide either the inorder, preorder,
	* or postorder traversals of this BST.
	* It has an instance variable called list that holds this list in one of the above orders.
	* Iterator remove method is not supported.
	* Inspired from BST class implementation we did in lecture on Ed.
	*
	* @author Walker Tupman
	* @version 05/01/2023
	*/
	private class BSTIterator implements Iterator<E> 
	{
		//list that holds a preorder, inorder, or postorder traversal of this BST
		private ArrayList<E> list;
		private int current;
		
		/**
		* Creates an iterator that iterates through this Binary Search Tree implementation.
		* Iterator can be inorder, preorder, or postorder.
		* Valid input for the param iterator is "inorder", "preorder", or "postorder",
		* to get the respective Iterator for this BST.
		* @param iterator - a String representation of the type of iterator 
		* that this class will construct
		*/
		public BSTIterator(String iterator)
		{
			//instantiate list to the type of iterator
			this.list = BST.this.toArray(iterator);
			//set current to 0
			this.current = 0;
		}
		
		/**
		* Returns true if the iteration has more elements. 
		* (In other words, returns true if next() would return an element rather than throwing an exception.)
		* @return true if the iteration has more elements
		*/
		public boolean hasNext()
		{
			return current < list.size();
		}
		
		/**
		* Returns the next element in the iteration.
		* @return the next element in the iteration
		* @throws NoSuchElementException - if the iteration has no more elements
		*/
		public E next() throws NoSuchElementException
		{
			//throw exception 
			if(current >= list.size())
			{
				throw new NoSuchElementException("the iteration has no more elements");
			}
			
			return list.get(current++);
		}
		
		/**
		* Remove method is not supported in this implementation of the Iterator class.
		* Throws an instance of UnsupportedOperationException and performs no other action. 
		* @throws UnsupportedOperationException - if the remove operation is not supported by this iterator
		*/
		public void remove() throws UnsupportedOperationException
		{
			throw new UnsupportedOperationException("remove operation not supported in this class");
		}
	 }
	 
	/**
	* A recursive method that adds to an ArrayList with the elements from this BST in inorder traversal order.
	* The ArrayList holds the generic E data from the nodes in this BST.
	* Inspired from BST class implementation we did in lecture on Ed.
	* @param node - a generic node from this BST
	* @param list - an ArrayList that will hold the data from this BST in inorder order
	* @throws NullPointerException - if node is null.
	*/
	 public void inorder(ArrayList<E> list, Node node) 
	 {
		 //base case
		 if (node == null ) return;
		 
		 //go left
		 inorder(list, node.left);
		 //process node
		 list.add(node.data); 
		 //go right
		 inorder(list, node.right ); 
	 }
	 
	/**
	* A recursive method that adds to an ArrayList with the elements from this BST in postorder traversal order.
	* The ArrayList holds the generic E data from the nodes in this BST.
	* @param node - a generic node from this BST
	* @param list - an ArrayList that will hold the data from this BST in postorder order
	* @throws NullPointerException - if node is null.
	*/ 
	 private void postorder(ArrayList<E> list, Node node)
	 {
		 //base case
		 if (node == null ) return; 
		 
		 //go left
		 postorder(list, node.left);
		 //go right
		 postorder(list, node.right); 
		 //process node 
		 list.add( node.data); 
	 }
	 
	/**
	* A recursive method that adds to an ArrayList with the elements from this BST in preorder traversal order.
	* The ArrayList holds the generic E data from the nodes in this BST.
	* @param node - a generic node from this BST
	* @param list - an ArrayList that will hold the data from this BST in preorder order
	* @throws NullPointerException - if node is null.
	*/
	 private void preorder(ArrayList<E> list, Node node)
	 {
		 //base case
		 if (node == null ) return; 
		 
		 //process node 
		 list.add( node.data);
		 //go left
		 preorder(list, node.left);
		 //go right
		 preorder(list, node.right); 
	 }
	 
	/**
	* Converts this BST into an ordered ArrayList and returns it.
	* The order can be inorder, postorder, or preorder.
	* The ArrayList holds the generic E data from the nodes in this BST.
	* Inspired from BST class implementation we did in lecture on Ed.
	* @param type - a string representation of the order that the BST will be iterated through
	*/
	 private ArrayList<E> toArray (String type) 
	 {
		 //if root is null nothing to turn into an array
		if (root == null ) 
		{
	        return null;
	    }
		//ArrayList to hold data 
	    ArrayList<E> list = new ArrayList<E> ();
	    
	    //based on what type of iterator is called, calls one of these methods
	    //inorder, postorder, preorder add elements of BST to list in their respective orders
	    if(type.equals("inorder"))
	    {
	    	inorder(list, root);
	    }
	    else if(type.equals("postorder"))
	    {
	    	postorder(list, root);
	    }
	    else
	    {
	        preorder(list, root);
	    }
	    
	    return list; 
	 }
	 
	/**
	* Returns an ArrayList that holds all paths from root to leaf from this BST.
	* The ArrayList holds the generic E data from the nodes in this BST.
	* @return null is this BST is empty
	* @return allPaths - ArrayList that holds all paths from root to leaf from this BST
	*/
	protected ArrayList<ArrayList<Node>> getAllPaths()
	{
		//if root is null then there's no path to get
		if(root == null)
		{
			return null;
		}
		//make ArrayList to hold all paths
		ArrayList<ArrayList<Node>> allPaths = new ArrayList<ArrayList<Node>>();
		//make ArrayList to hold one path
		ArrayList<Node> path = new ArrayList<Node>();
		//reference of root to use in recursive method, don't know if necessary
		Node copy = root;
		
		//call recursive method
		allPaths = findAllPaths(allPaths, copy, path);
		return allPaths;
		 
	 }
	 
	/**
	* Recursive helper method for method getAllPaths()
	* Finds and returns an ArrayList that holds all paths from root to leaf from this BST.
	* The ArrayList holds the generic E data from the nodes in this BST.
	* @param allPaths - the ArrayList that represents all paths from root to leaf of this BST
	* @param node - a node of this BST
	* @param path - an ArrayList filled with generic nodes that represents one path from root to leaf of this BST.
	* @return allPaths - an ArrayList that holds all paths from root to leaf from this BST
	*/
	private ArrayList<ArrayList<Node>> findAllPaths(ArrayList<ArrayList<Node>> allPaths, Node node, ArrayList<Node> path)
	{
		//if node is null, no more nodes to explore so return allPaths
		if(node == null)
		{
			return allPaths;
		}
		 
		//add node to path
		path.add(node);
		
		//if leaves of node are null then it's end of path of add it to allPaths
		if(node.left == null && node.right == null)
		{
			allPaths.add(path);
		 	return allPaths;
		}
		//recursive calls to visit other nodes / paths
		else
		{
			findAllPaths(allPaths, node.left, new ArrayList<>(path));
			findAllPaths(allPaths, node.right, new ArrayList<>(path));
		}
		 
		return allPaths;
	 }
}
