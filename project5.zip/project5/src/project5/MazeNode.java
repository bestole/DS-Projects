package project5;

/**
* The MazeNode class represents the points in a maze at which a Hero object can collect life-points
* and at which they need to make a decisions as to which way to continue. 
* It is capable of storing the label of the node and the number of possible life points a 
* Hero object can collect at this maze node.
* 
* @author Walker Tupman
* @version 05/01/2023
*/
public class MazeNode implements Comparable<MazeNode>{
	private int lifePoints;
	private String label;
	public MazeNode(int lifePoints, String label)
	{
		//instantiate instance variables
		this.lifePoints = lifePoints;
		this.label = label;
	}
	
	/**
	* Returns the amount of lifePoints held in MazeNode.
	* @return lifePoints - an int representation of the number of lifePoints in a MazeNode.
	*/
	public int getLifePoints()
	{
		return lifePoints;
	}
	
	/**
	* Returns the label of a MazeNode.
	* @return label - a string representation of a MazeNode's label.
	*/
	public String getLabel()
	{
		return label;
	}
	
	/**
	* Compares this object with other for order.
	* Comparisons are cave sensitive.
	* Returns a negative integer if this object's value is alphabetically smaller than other. 
	* Returns a positive integer if this object's value is alphabetically greater than other. 
	* Returns zero if two MazeNode objects are the same.
	* @param other - the object to be compared with this object
	* @return a negative integer, zero, or a positive integer as this object is less than, equal to, or greater than other.
	* @throws NullPointerException - if other is null
	*/
	@Override
	public int compareTo(MazeNode other) throws NullPointerException
	{
		//check if other is null
		if(other == null)
		{
			throw new NullPointerException("do not pass in null.");
		}
		
		//use String compareTo to compare 
		return this.label.compareTo(other.label);
	}
	
	/**
	* Returns the string representation of this object.
	* @return string representation of this object
	*/
	@Override
	public String toString()
	{ 
		return label + " " + lifePoints;
	}
}
