package project5;

/**
* The Hero class represents a hero traveling through a maze.
* An object of this class is capable of keeping track of all the 
* life points that our hero possesses at any given time. 
* This information should be updated as the hero travels along 
* the different potential paths through the maze.
* 
* @author Walker Tupman
* @version 05/01/2023
*/
public class Hero {
	//instance variable to keep track of a Hero's lifePoints
	private int lifePoints;
	
	/**
	* Constructs a Hero object with default (0) lifePoints; 
	* A Hero object keeps track of its life points while it travels through a maze.
	*/
	public Hero()
	{
		//instantiate lifePoints
		this.lifePoints = 0;
	}
	
	/**
	* Moves a hero object one level down in a Maze. 
	* A Hero object loses one lifePoint for each level it travels down.
	*/
	public void move()
	{
		lifePoints--;
	}
	
	/**
	* Adds lifePoints to a Hero object.
	* @param life - the amount of lifePoints to be added to the Hero.
	*/
	public void addLP(int life)
	{
		lifePoints += life;
	}
	
	/**
	* Checks whether or not a Hero object is alive.
	* Hero objects are considered dead when they have less than zero lifePoints.
	* @return true - is Hero is alive, false - if Hero is dead (less than 1 lifePoints).
	*/
	public boolean isAlive()
	{
		return lifePoints > 0;
	}
	
	/**
	* Puts the Hero on a new path through a maze.
	* Hero objects start at zero lifePoints when starting a new path.
	* Updates Hero's lifePoints to be zero.
	*/
	public void newPath()
	{
		lifePoints = 0;
	}
	
	/**
	* Returns the Hero's lifePoints instance variable.
	* @return lifePoints - an int representing a Hero's lifePoints.
	*/
	public int getLP()
	{
		return lifePoints;
	}
}
