package project5;
import java.util.*;

/**
* The Maze class is a Binary Search Tree implementation that 
* represents a maze full of Nodes that contain the MazeNode object.
* It is capable of storing a list of all paths from its root to leafs in it's data field allPaths.
* It uses a Hero object to go through the maze and validate paths that have an exit.
* It is capable of validating paths that allow a Hero object to this maze.
* 
* @author Walker Tupman
* @version 05/01/2023
*/
public class Maze extends BST<MazeNode>{
	//ArrayList that can contain all possible paths in this maze
	private ArrayList<ArrayList<Node>> allPaths;
	public Maze()
	{	
		//use inherited constructor of BST
		super();
	}
	
	/**
	* Validates all paths in a Maze BST and uses a Hero object to explore this maze.
	* Calls helper method explorePath() to explore and validate a singular path.
	* explorePath() prints out valid paths.
	* @param hero - the Hero object used to explore the paths in this Maze class.
	* @throws NullPointerException - if hero is null
	*/
	public void validatePaths(Hero hero) throws NullPointerException
	{
		//instantiate allPaths instance variable
		this.allPaths = super.getAllPaths();
		
		//case where there's no valid input 
		if(allPaths == null)
		{
			return;
		}
		
		//iterate through all all paths in this maze and validate them using explorePath method
		for(int i = 0; i < allPaths.size(); i++)
		{
			//reset hero's lifePoints back to 0
			hero.newPath();
			//get new path to explore
			ArrayList<Node> path = this.allPaths.get(i);
			this.explorePath(path, hero);
		}
	}
	
	/**
	* Returns true is a path is considered valid.
	* Each Node in a path has a MazeNode object inside of it. 
	* Valid paths contain enough lifePoints for the Hero object to go through the maze and have an exit.
	* An exit is a leaf node on the bottom level of the maze.
	* Any leaf node not on the bottom level of the maze is considered a trap door and ends our Hero object's journey.
	* When a Hero object lands on a new MazeNode object, it absorbs the lifePoints contained in that node.
	* Prints a path if it is considered valid.
	* @param path - an ArrayList containing Node objects. It represents one path through a Maze.
	* @param hero - a Hero object that will be used to see if this path has enough lifePoints for
	* a hero to escape
	* @return true - if path is valid, false - if path is not valid.
	*/
	public boolean explorePath(ArrayList<Node> path, Hero hero)
	{
		//used to hold representations of a valid path
		StringBuilder validPath = new StringBuilder();
		//used to check if path is valid
		boolean valid = false;
		//iterate Hero object through each node
		for(int j = 0; j < path.size(); j++)
		{
			//path contains a "trap door" so automatically disqualify
			if(path.size() < this.height())
			{
				break;
			}
			
			Node node = path.get(j);
			//MazeNode data inside node
			MazeNode data = getData(node);
			String label = data.getLabel();
			int LP = data.getLifePoints();
			
			//adds lifePoints from this node to hero's lifePoints
			hero.addLP(LP);
			
			//if hero is at exit and has at least 0 lifePoints this is a valid path
			if(j == path.size() - 1 && hero.getLP() >= 0)
			{
				valid = true;
			}
			else if(!(hero.isAlive()))
			{
				break;
			}
			//move hero to next level
			hero.move();
			
			//add this node's label to end of validPath
			validPath.append(label);
			if(j != path.size() - 1)
			{
				validPath.append(" ");
			}
		}	
		//prints this path if valid
		if(valid)
		{
			System.out.println(validPath);
			return true;
		}
		//not a valid path
		return false;
	}
	
	/**
	* Returns the string representation of this object.
	* @return string representation of this object
	*/
	@Override
	public String toString()
	{
		//holds all paths in maze
		StringBuilder maze = new StringBuilder();
		this.allPaths = super.getAllPaths();
		for(int i = 0; i < allPaths.size(); i++)
		{
			ArrayList<Node> path = this.allPaths.get(i);
			for(int j = 0; j < path.size(); j++)
			{
				//append this node's data to this path in the maze
				Node temp = path.get(j);
				MazeNode data = getData(temp);
				maze.append(data);
				
				//arrow to show next node in path
				if(j < path.size() - 1)
				{
					maze.append(" -> ");
				}
			}
			//go to next line for next path
			maze.append("\n");
		}
		return maze.toString();
	}
	
}