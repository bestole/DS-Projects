package project5;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

/**
* The BinaryTreeMaze class is responsible for parsing and validating the command line arguments, 
* reading and parsing the input file, producing any error messages, and
* handling any exceptions thrown by other classes, and producing output.
* This class contains the main method to be used by the other classes for this project.
* Code used to open file from args is inspired by Joanna's ColorConverter class from project1.
* 
* @author Walker Tupman
* @version 05/01/2023
*/
public class BinaryTreeMaze {
	public static void main(String[] args)
	{
		//check if there's no command line input
		if (args.length == 0) 
		{
			System.err.println("Usage Error: the program expects file name as an argument.\n");
			System.exit(1);
		}
		//instantiate file from command line argument at index 0
		File mazeFile = new File(args[0]);
		
		//if the file does not exist throw error
		if (!mazeFile.exists())
		{
			System.err.println("Error: the file " + mazeFile.getAbsolutePath()+" does not exist.\n");
			System.exit(1);
		}
		
		//if file is unreadable throw error 
		if (!mazeFile.canRead()){
			System.err.println("Error: the file "+mazeFile.getAbsolutePath()+
											" cannot be opened for reading.\n");
			System.exit(1);
		}
		
		//scanner for reading file
		Scanner inMaze = null;
		
		//open file to read
		try {
			inMaze = new Scanner (mazeFile) ;
		} catch (FileNotFoundException e) {
			System.err.println("Error: the file "+mazeFile.getAbsolutePath()+
											" cannot be opened for reading.\n");
			System.exit(1);
		}
		
		//instantiate variables to hold data from file 
		ArrayList<MazeNode> list = new ArrayList<MazeNode>(); 
		String line = null; 
		Scanner parseLine = null; 
		String label  = null;
		String LifePoints = null; 
		Maze maze = new Maze();
		
		//while loop to assign data to variables above from file 
		while (inMaze.hasNextLine()) {
			try { 
				line = inMaze.nextLine(); 
				parseLine = new Scanner(line);
				parseLine.useDelimiter(" "); 
				label = parseLine.next();
				LifePoints = parseLine.next();
				
			}
			//if line is formatted wrong or has nothing continue 
			catch (NoSuchElementException ex ) {
				System.err.println(line);
				continue; 	
			}
			//use data from file to create add nodes to Maze BST
			try {
				MazeNode temp = new MazeNode(Integer.parseInt(LifePoints), label);
				
				maze.add(new MazeNode(Integer.parseInt(LifePoints), label));
				
				list.add(temp);
			}
			catch (IllegalArgumentException ex ) {
				
			}
		}
		
		//instantiate Hero object and give them a cool name
		Hero BonakdarianTheSlayer = new Hero();
		
		//call method from maze to output all valid paths for this hero.
		maze.validatePaths(BonakdarianTheSlayer);
		//System.out.println(maze.toStringTreeFormat());
		//System.out.println(maze.toString());
	}
	
}
