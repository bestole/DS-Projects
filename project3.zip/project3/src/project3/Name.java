package project3;

/**
* The Name class is used to represent a person's name.
* It stores information about first name, last name, and middle initial.
* Each name object must contain a last name.
* Name objects are able to be compared with other Name objects with case insensitive alphabetic ordering.
*
* @author Walker Tupman
*/
public class Name implements Comparable<Name> {
	//declare instance variables for Name class
	private String last;
	private String first;
	private String mid;
	
	/**
	* Creates a Name object with only a last name represented by the string argument last.
	* First name and middle initial are represented by empty strings.
	* The first, middle, and last names should consist of only alphabetic characters.
	* @param last - a string representation of a person's last name.
	* @throws IllegalArgumentException - if last is null or is an empty string.
	*/
	public Name(String last)
	{
		//check for last being null or an empty string
		if(last == null || last.length() == 0)
		{
			throw new IllegalArgumentException("Last name required. Do not input an empty string or null.");
		}
		
		this.last = last;
		first = "";
		mid = "";
	}
	
	/**
	* Creates a Name object with a last and first name represented by the string arguments last and first.
	* Middle initial is represented by an empty string.
	* The first, middle, and last names should consist of only alphabetic characters.
	* @param last - a string representation of a person's last name.
	* @param first - a string representation of a person's first name.
	* @throws IllegalArgumentException - if last is null or is an empty string.
	*/
	public Name(String last, String first)
	{
		//check for last being null or an empty string
		if(last == null || last.length() == 0)
		{
			throw new IllegalArgumentException("Last name required. Do not input an empty string or null.");
		}
		
		//instantiate instance variables last, first, and mid
		this.last = last;
		this.first= first;
		this.mid = "";
		
		//if first is null replace it with empty string to make using it later easier
		if(this.first == null)
		{
			this.first = "";
		}
		
	}
	
	/**
	* Creates a Name object with a last name, first name, and middle initial represented
	* by the string arguments last and first, and the char argument mid.
	* Middle initial is represented by an empty string if it does not contain an alphabetic character.
	* The first, middle, and last names should consist of only alphabetic characters.
	* @param last - a string representation of a person's last name.
	* @param first - a string representation of a person's first name.
	* @param mid - a char representation of a person's middle initial.
	* @throws IllegalArgumentException - if last is null or is an empty string.
	*/
	public Name(String last, String first, char mid)
	{
		//check for last being null or an empty string
		if(last == null || last.length() == 0)
		{
			throw new IllegalArgumentException("Last name required. Do not input an empty string or null.");
		}
		
		//instantiate instance variables last, first, and mid
		this.last = last;
		this.first = first;
		this.mid = "";
		
		//if first is null replace it with empty string to make using it later easier
		if(this.first == null)
		{
			this.first = "";
		}
		
		//if mid is an alphabetic character concatenate it to the end of the mid instance variable
		if((mid >= 65 && mid <= 90) || (mid >= 97 && mid <= 122))
		{
			this.mid += mid;
		}
	}
	
	/**
	* Determines if this Name object is equal to obj. 
	* Two Name objects are equal equal if their first name, last name and middle initial are the same. 
	* This comparison is case insensitive.
	* @param obj - the object to be compared to this object
	* @return true if two objects are equal, false otherwise
	*/
	@Override
	public boolean equals(Object obj)
	{
	    //prerequisite checks before testing equality of these two objects
		if(this == obj)
		{
			return true;
		}
		if(obj == null)
		{
			return false;
		}
		if(!(Name.class.isInstance(obj)))
		{
			return false;
		}
		
		//cast Object obj to Name class
		Name o = (Name)obj;
		
		//check for case insensitive equality
		if(this.last.equalsIgnoreCase(o.last))
		{
			if(this.first.equalsIgnoreCase(o.first))
			{
				if(this.mid.equalsIgnoreCase(o.mid))
				{
					return true;
				}
				return false;
			}
			return false;
		}
		return false;
	}
	
	/**
	* Compares this object with other for order.
	* All comparisons are case insensitive.
	* Returns a negative integer if this object's value is alphabetically smaller than other. 
	* Returns a positive integer if this object's value is alphabetically greater than other. 
	* Returns zero if two Name objects are the same.
	* If middle initial or first name from this object or other object are empty strings, they are not compared.
	* @param other - the object to be compared with this object
	* @return a negative integer, zero, or a positive integer as this object is less than, equal to, or greater than other.
	* @throws NullPointerException - if other is null
	*/
	public int compareTo(Name other)
	{
	    //prerequisite checks before comparing these two Name objects
		if(other == this)
		{
			return 0;
		}
		if(other == null)
		{
			throw new NullPointerException("do not pass in null");
		}
		
		//compare this last name and other last name
		if(this.last.compareToIgnoreCase(other.last) < 0)
		{
			return -1;
		}
		else if(this.last.compareToIgnoreCase(other.last) > 0)
		{
			return 1;
		}
		
		//compare this first name and other first name
		//don't compare if this first or other first are empty strings
		if(this.first != "" && other.first != "")
		{
			if(this.first.compareToIgnoreCase(other.first) < 0)
			{
				return -1;
			}
			else if(this.first.compareToIgnoreCase(other.first) > 0)
			{
				return 1;
			}
		}
		
		//compare this middle initial and other middle initial
		//don't compare if this mid or other mid are empty strings
		if(this.mid != "" && other.mid != "")
		{
			if(this.mid.compareToIgnoreCase(other.mid) < 0)
			{
				return -1;
			}
			else if(this.mid.compareToIgnoreCase(other.mid) > 0)
			{
				return 1;
			}
		}
		
		return 0;
	}
	
	/**
	* Returns a string representation of a person's last name.
	* @return last - a person's last name.
	*/
	public String getLast()
	{
		return last;
	}
	
	/**
	* Returns a string representation of a person's last name.
	* A person's first name may be an empty string.
	* @return last - a person's last name.
	*/
	public String getFirst()
	{
		return first;
	}
	
	/**
	* Returns a string representation of a person's middle initial.
	* A person's middle initial may be an empty string.
	* @return last - a person's middle initial.
	*/
	public String getMid()
	{
		return mid;
	}
	
}
