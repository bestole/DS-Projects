package project3;

/**
* The Location class is used to represent a location.
* It stores information about city, state, country, and zip code.
* Each location object must contain a city.
* Location objects are able to compared with other Location objects with case insensitive alphabetic ordering.
*
* @author Walker Tupman
*/
public class Location implements Comparable<Location> {
	//declare instance variables
	String city;
	String state;
	String country;
	String zip;
	
	/**
	* Creates a Location object with a city, state, country, and zip code represented 
	* by the string arguments city, state, country, and zip respectively.
	* City, state, and country should consist of only alphabetic characters. Zip should consist of only numeric characters.
	* @param city - a string representation of a city of a location.
	* @param state - a string representation of a state of a location.
	* @param country - a string representation of a country of a location.
	* @param zip - a string representation of a zip code of a location.
	* @throws IllegalArgumentException - if city is null or is an empty string.
	* @throws IllegalArgumentException - if zip length is greater than 5 or contains non numeric characters.
	*/
	public Location(String city, String state, String country, String zip)
	{
		//check because city is required for a Location object
		if(city == null || city.length() == 0)
		{
			throw new IllegalArgumentException("City required");
		}
		
		//instantiate instance variables
		this.city = city;
		this.state = state;
		this.country = country;
		
		//check for null arguments and switch them to empty strings for easier use
		if(state == null)
		{
			this.state = "";
		}
		if(country == null)
		{
			this.country = "";
		}
		if(zip == null)
		{
			zip = "";
		}
		
		//checks to make sure zip is valid before assigning it to this.zip
		if(zip.length() > 5)
		{
			throw new IllegalArgumentException("zip invalid");
		}
		try
		{
			for(int i = 0; i < zip.length(); i++)
			{
				
				Integer.parseInt(String.valueOf(zip.charAt(i)));
				
			}
		}
		catch(NumberFormatException e)
		{
			throw new IllegalArgumentException("zip code not valid");
		}
		//adds leading zeroes to make zip valid if it is less than 5 numeric characters
		if(zip.length() < 5)
		{
			for(int i = zip.length(); i < 5; i++)
			{
				zip = "0" + zip;
			}
		}
		
		//assign zip to this.zip
		this.zip = zip;
	}
	
	/**
	* Returns a string representation of a city.
	* @return city - a city of a location.
	*/
	public String getCity()
	{
		return city;
	}
	
	/**
	* Returns a string representation of a state.
	* A state may be an empty string.
	* @return state - a state of a location.
	*/
	public String getState()
	{
		return state;
	}
	
	/**
	* Returns a string representation of a country.
	* A country may be an empty string.
	* @return country - a country of a location.
	*/
	public String getCountry()
	{
		return country;
	}
	
	/**
	* Returns a string representation of a zip code.
	* A zip code may be an empty string.
	* @return zip - a zip code of a location.
	*/
	public String getZip()
	{
		return zip;
	}
	
	/**
	* Determines if this Location object is equal to obj. 
	* Two Location objects are equal if their city, state, country, and zip are the same. 
	* This comparison is case insensitive.
	* @param obj - the object to be compared to this object
	* @return true if two objects are equal, false otherwise
	*/
	@Override
	public boolean equals(Object obj)
	{
		//prerequisite checks before testing equality of these two objects
		if(this == obj)
		{
			return true;
		}
		if(obj == null)
		{
			return false;
		}
		if(!(Location.class.isInstance(obj)))
		{
			return false;
		}
		
		//cast Object obj to Location class
		Location o = (Location)obj;
		
		//check for case insensitive equality
		if(this.city.equalsIgnoreCase(o.city))
		{
			if(this.state.equalsIgnoreCase(o.state))
			{
				if(this.country.equalsIgnoreCase(o.country))
				{
					if(this.zip.equals(o.zip))
					{
						return true;
					}
					return false;
				}
				return false;
			}
			return false;
		}
		return false;
	}
	
	/**
	* Compares this object with other for order.
	* All comparisons are case insensitive.
	* Returns a negative integer if this object's value is alphabetically smaller than other. 
	* Returns a positive integer if this object's value is alphabetically greater than other. 
	* Returns zero if two Location objects are the same.
	* If zip, state, or country from this object or other object are empty strings, they are not compared.
	* @param other - the object to be compared with this object
	* @return a negative integer, zero, or a positive integer as this object is less than, equal to, or greater than other.
	* @throws NullPointerException - if other is null
	*/
	public int compareTo(Location other)
	{
	    //prerequisite checks before comparing these two Location objects
		if(other == this)
		{
			return 0;
		}
		if(other == null)
		{
			throw new NullPointerException("do not pass in null.");
		}
		
		//compare this zip code and other zip code
		if(this.zip.compareToIgnoreCase(other.zip) < 0)
		{
			return -1;
		}
		else if(this.zip.compareToIgnoreCase(other.zip) > 0)
		{
			return 1;
		}
		
		//compare this city and other city
		if(this.city.compareToIgnoreCase(other.city) < 0)
		{
			return -1;
		}
		else if(this.city.compareToIgnoreCase(other.city) > 0)
		{
			return 1;
		}
		
		//compare this state and other state
		//don't compare if this state or other state are empty strings
		if(this.state != "" && other.state != "")
		{
			if(this.state.compareToIgnoreCase(other.state) < 0)
			{
				return -1;
			}
			else if(this.state.compareToIgnoreCase(other.state) > 0)
			{
				return 1;
			}
		}
		
		//compare this country and other country
		//don't compare if this country or other country are empty strings
		if(this.country != "" && other.country != "")
		{
			if(this.country.compareToIgnoreCase(other.country) < 0)
			{
				return -1;
			}
			else if(this.country.compareToIgnoreCase(other.country) > 0)
			{
				return 1;
			}
		}
		
		return 0;
	}
}
