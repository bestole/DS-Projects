package project3;
import java.util.ArrayList;

/**
* The Recordlist class is used to store information all the unique Record objects.
* This class should inherits from the ArrayList<Record> class. 
* This class provides all functionality of the ArrayList, but adds to it a few functions
* that are specialized to a list that is designed to store and work with Record objects.
*
* @author Walker Tupman
*/
public class RecordList extends ArrayList<Record> {
	
	/**
	* Creates a default RecordList object using the inherited ArrayList default constructor.
	* A RecordList object stores a list of unique record objects.
	*/
	public RecordList()
	{
		
	}
	
	/**
	* Searches through a RecordList object and creates a new list of records 
	* for which the keyword is a substring of person's last name or first name.
	* This method is case insensitive.
	* @param keyword - the keyword that will be used to search for a person's last or first name.
	* @return a list of records for which the keyword is a substring of person's last name or first name.
	* or null if there are no Record objects matching the keyword.
	* @throws IllegalArgumentException - if keyword is null or an empty string
	*/
	public RecordList getByName(String keyword)
	{
		//check to make sure keyword is valid
		if(keyword == null || keyword.length() == 0)
		{
			throw new IllegalArgumentException("keyword for name required");
		}
		
		//make keyword lower case so searching is case insensitive
		keyword.toLowerCase();
		
		//declare variables and list that will be used for this method 
		RecordList name = new RecordList();
		String last;
		String first;
		
		//search through this RecordList object and add first/last names with keyword inside of them to name RecordList
		for(int i = 0; i < this.size(); i++)
		{
			last = this.get(i).getName().getLast().toLowerCase();
			first = this.get(i).getName().getFirst().toLowerCase();
			if(last.contains(keyword)|| first.contains(keyword))
			{
				name.add(this.get(i));
			}
		}
		
		//if no matches were found for keyword return null
		if(name.size() == 0)
		{
			return null;
		}
		
		//sort the list of matched names using ArrayList method
		name.sort(null);
		
		return name;
	}
	
	/**
	* Searches through a RecordList object and creates a new list of records 
	* for which the keyword is a substring of the city at which the tax preparer is located.
	* This method is case insensitive.
	* @param keyword - the keyword that will be used to search for cities at which the tax preparer is located.
	* @return a list of records for which the keyword is a substring of the city at which the tax preparer is located.
	* or null if there are no Record objects matching the keyword.
	* @throws IllegalArgumentException - if keyword is null or an empty string
	*/
	public RecordList getByCity(String keyword)
	{
		//check to make sure keyword is valid
		if(keyword == null || keyword.length() == 0)
		{
			throw new IllegalArgumentException("keyword for name required");
		}
		
		//make keyword lower case so searching is case insensitive
		keyword.toLowerCase();
		
		//declare variable and list that will be used for this method 
		RecordList loc = new RecordList();
		String city;
		
		//search through this RecordList object and add cities with keyword inside of them to city RecordList
		for(int i = 0; i < this.size(); i++)
		{
			city = this.get(i).getLocation().getCity().toLowerCase();
			if(city.contains(keyword))
			{
				loc.add(this.get(i));
			}
		}
		
		//if no matches were found for keyword return null
		if(loc.size() == 0)
		{
			return null;
		}
		
		//sort the list of matched names using ArrayList method
		loc.sort(null);
		
		return loc;
	}
	
	/**
	* Searches through a RecordList object and creates a new list of records 
	* for which the zip-code matches the zip argument exactly.
	* This method is case insensitive.
	* @param zip - the zip that will be used to search for zip codes that match the zip argument exactly.
	* @return a list of records for which zip is an exact match for zip code stored in a Record object.
	* or null if there are no Record objects matching the zip.
	* @throws IllegalArgumentException - if zip is null or a string that does not represent a five digit zip code
	* (i.e., contains any characters other than digits, or contains fewer or more than five characters).
	*/
	public RecordList getByZip(String zip)
	{	
		//check to make sure zip is valid
		if(zip == null || zip.length() < 5 || zip.length() > 5)
		{
			throw new IllegalArgumentException("keyword for zip required");
		}
		try
		{
			for(int i = 0; i < zip.length(); i++)
			{
				
				Integer.parseInt(String.valueOf(zip.charAt(i)));
				
			}
		}
		catch(NumberFormatException e)
		{
			throw new IllegalArgumentException("zip code not valid");
		}
		
		//declare variable and list that will be used for this method 
		RecordList zCode = new RecordList();
		String z;
		
		//search through this RecordList object and add zip codes with zip inside of them to zCode RecordList
		for(int i = 0; i < this.size(); i++)
		{
			z = this.get(i).getLocation().getZip();
			if(z.equals(zip))
			{
				zCode.add(this.get(i));
			}
		}
		
		//if no matches were found for keyword return null
		if(zCode.size() == 0)
		{
			return null;
		}
		
		//sort the list of matched names using ArrayList method
		zCode.sort(null);
		
		return zCode;
	}
	
	/**
	* Returns the string representation of this object.
	* @return string representation of this object
	*/
	@Override
	public String toString()
	{
		String total = "";
		for(int i = 0; i < this.size(); i++)
		{
			total += this.get(i) + "\n\n";
		}
		return total;
	}

}
