package project3;

/**
* The Record class is used to stores information about a particular record/row from an input file.
* It stores information about a person's name, location, and business.
* Each location object must a Name object and Location object.
* Record objects are able to compared with other Record objects with case insensitive alphabetic ordering.
*
* @author Walker Tupman
*/
public class Record implements Comparable<Record> {
	//declare instance variables
	private Name name;
	private String business;
	private Location location;
	
	/**
	* Creates a Record object with a name, business, and location represented
	* by the Name object argument name, the String argument business, and the Location object location.
	* name and location should be non-null objects, while business can be empty or null.
	* @param name - a Name object representation of a person's name.
	* @param business - a string representation of a business associated with a record.
	* @param location - a Location object representation of a location associated with a record.
	* @throws IllegalArgumentException - if name or location arguments are null objects.
	*/
	public Record(Name name, String business, Location location)
	{
		//check to make sure name and location aren't null
		if(name == null || location == null)
		{
			throw new IllegalArgumentException("Name and Business must not be null objects");
		}
		
		//instantiate instance variables.
		this.name = name;
		this.business = business;
		this.location = location;
		
		//check for null argument and switch to empty string for easier use
		if(business == null)
		{
			this.business = "";
		}
	}
	
	/**
	* Returns a Name object which represents a person's name.
	* @return name - a person's name which include last, first, and middle initial.
	*/
	public Name getName()
	{
		return name;
	}
	
	/**
	* Returns a string representation of a business.
	* @return business - a business stored in a Record object.
	*/
	public String getBusiness()
	{
		return business;
	}
	
	/**
	* Returns a Location object which represents a location associated with each record.
	* @return location - a location stored in a Record object.
	*/
	public Location getLocation()
	{
		return location;
	}
	
	/**
	* Determines if this Record object is equal to obj. 
	* Two Location objects are equal if their name, location, and business are the same.
	* This comparison is case insensitive.
	* @param obj - the object to be compared to this object
	* @return true if two objects are equal, false otherwise
	*/
	@Override
	public boolean equals(Object obj)
	{
		//prerequisite checks before testing equality of these two objects
		if(this == obj)
		{
			return true;
		}
		if(obj == null)
		{
			return false;
		}
		if(!(Record.class.isInstance(obj)))
		{
			return false;
		}
		
		//cast Object obj to Record class
		Record o = (Record)obj;
		
		//make equality comparison using equals methods from String, Name, and Location objects
		boolean compare = this.name.equals(o.name) && this.location.equals(o.location) 
				&& this.business.toLowerCase().equals(o.business.toLowerCase());
		
		return compare;
	}
	
	/**
	* Compares this object with other for order.
	* All comparisons are case insensitive.
	* Returns a negative integer if this object's location and name is alphabetically smaller than other. 
	* Returns a positive integer if this object's location and name is alphabetically greater than other. 
	* Returns zero if two Record objects are the same.
	* @param other - the object to be compared with this object
	* @return a negative integer, zero, or a positive integer as this object is less than, equal to, or greater than other.
	* @throws NullPointerException - if other is null
	*/
	public int compareTo(Record other)
	{
		//prerequisite checks before comparing these two Record objects
		if(other == this)
		{
			return 0;
		}
		if(other == null)
		{
			throw new NullPointerException("do not pass in null.");
		}
		
		//compare this Name object and other Name object
		if(this.name.compareTo(other.name) < 0)
		{
			return -1;
		}
		else if(this.name.compareTo(other.name) > 0)
		{
			return 1;
		}
		
		//compare this Location object and other Location object
		if(this.location.compareTo(other.location) < 0)
		{
			return -1;
		}
		else if(this.location.compareTo(other.location) > 0)
		{
			return 1;
		}
		
		return 0;
	}
	
	/**
	* Returns the string representation of this object.
	* @return string representation of this object
	*/
	@Override
	public String toString()
	{
		return name.getLast() + ", " + name.getFirst() + ", " + name.getMid() + "\n\t" + business + ", " 
		+ location.getCity() + ", " + location.getState() + ", " + location.getCountry() + ", " + location.getZip();
	}
}
